<?php
print_r($_POST);
print_r($_FILES);
?>